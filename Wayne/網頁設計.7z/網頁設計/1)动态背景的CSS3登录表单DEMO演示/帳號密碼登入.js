<!--密碼查核JavaScript程式-->
<SCRIPT LANGUAGE="JavaScript"> 

<!-- 

function Login(){ 

var done=0; 

var username=document.login.username.value; 

username=username.toLowerCase(); 

var password=document.login.password.value; 

password=password.toLowerCase(); 

if (username=="Username" && password=="Password") { window.location="登入成功的網址"; done=1; } 

if (done==0) { alert("您的帳號或密碼錯誤!!"); } 

} 

--> 

</SCRIPT> 

